/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 * 32 set, 1 line per set, 32 bytes per line. 
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */

/** 32 ✖ 32 矩阵 (miss < 300)
 * 分块的大小为8x8时,矩阵内部不会存在缓存冲突
 * 通过局部变量可以解决对角线元素缓存冲突的情况
 * miss次数为:16x16 + 4x7 + 3 = 287
 * 16x16是16个分块矩阵中A第一行和B第一列的固定miss
 * 4x7是4个对角分块矩阵复制A[M]时会替换B[M]产生的7次miss(每个对角阵的第一行除外)
 * eg:B的第一列赋值完成后(此时cache中是B[0]-B[7]),复制A[1][1]时会替换B[1],之后同理
 */

// char transpose_submit_desc[] = "Transpose submission";
// void transpose_submit(int M, int N, int A[N][M], int B[M][N])
// {
//     int i, j, k;
//     int tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8;

//     for(i = 0; i < N; i += 8) {
//         for(j = 0; j < M; j += 8){
//             for(k = i; k < i+8; ++k){
//                 tmp1 = A[k][j];
//                 tmp2 = A[k][j+1];
//                 tmp3 = A[k][j+2];
//                 tmp4 = A[k][j+3];
//                 tmp5 = A[k][j+4];
//                 tmp6 = A[k][j+5];
//                 tmp7 = A[k][j+6];
//                 tmp8 = A[k][j+7];

//                 B[j][k] = tmp1;
//                 B[j+1][k] = tmp2;
//                 B[j+2][k] = tmp3;
//                 B[j+3][k] = tmp4;
//                 B[j+4][k] = tmp5;
//                 B[j+5][k] = tmp6;
//                 B[j+6][k] = tmp7;
//                 B[j+7][k] = tmp8;
//             }
//         }
//     }
// }

/** 64 ✖ 64矩阵 (miss < 1300)
 * 
 */

char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    
    int i, j, p, q, h, k;

    int tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12;

    for(i=0; i<N; i+=8){
        for(j=0; j<M; j+=8){
            for(h=j; h<j+4; ++h){
                for(p=i; p<i+4; ++p){
                    tmp1 = A[p][h];
                    tmp2 = A[p][h+1];
                    tmp3 = A[p][h+2];
                    tmp4 = A[p][h+3];

                    tmp5 = A[p][h+4];
                    tmp6 = A[p][h+5];
                    tmp7 = A[p][h+6];
                    tmp8 = A[p][h+7];

                    B[h][p] = tmp1;
                    B[h+1][p] = tmp2;
                    B[h+2][p] = tmp3;
                    B[h+3][p] = tmp4;
                }

                for(q=i+4; q<i+8; ++q){
                    tmp1 = A[q][h];
                    tmp2 = A[q][h+1];
                    tmp3 = A[q][h+2];
                    tmp4 = A[q][h+3];

                    tmp9 = A[q][h+4];
                    tmp10 = A[q][h+5];
                    tmp11 = A[q][h+6];
                    tmp12 = A[q][h+7];

                    B[h][q] = tmp1;
                    B[h+1][q] = tmp2;
                    B[h+2][q] = tmp3;
                    B[h+3][q] = tmp4;

                }
            }

            for(k=j+4; k<j+8; ++k){
                for(p=i; p<i+4; ++p){
                    tmp1 = tmp5;
                    tmp2 = tmp6;
                    tmp3 = tmp7;
                    tmp4 = tmp8;

                    B[k][p] = tmp1;
                    B[k+1][p] = tmp2;
                    B[k+2][p] = tmp3;
                    B[k+3][p] = tmp4;
                }

                for(q=i+4; q<i+8; ++q){
                    tmp1 = tmp9;
                    tmp2 = tmp10;
                    tmp3 = tmp11;
                    tmp4 = tmp12;

                    B[k][p] = tmp1;
                    B[k+1][p] = tmp2;
                    B[k+2][p] = tmp3;
                    B[k+3][p] = tmp4;
                }
            }
        }
    }
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

